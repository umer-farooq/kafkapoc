package com.fab.pb.poc.producer;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.fab.pb.poc.domain.generated.Payment;

@Component
@Slf4j
public class PaymentProducer {

    KafkaTemplate<String, Payment> kafkaTemplate;

    public PaymentProducer(KafkaTemplate<String, Payment> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(Payment paymentAvro) {

        var producerRecord = new ProducerRecord<>("payments",
        		paymentAvro.getId().toString(), paymentAvro);
        ListenableFuture<SendResult<String, Payment>> listenableFuture
                = kafkaTemplate.send(producerRecord);

        listenableFuture.addCallback(new ListenableFutureCallback<SendResult<String, Payment>>() {
            @Override
            public void onFailure(Throwable ex) {
                handleFailure(paymentAvro, ex);
            }

            @Override
            public void onSuccess(SendResult<String, Payment> result) {
                handleSuccess(paymentAvro, result);
            }
        });


    }

    private void handleFailure(Payment paymentAvro, Throwable ex) {
        log.error("Error Sending the message for {} and the exception is : {}", paymentAvro
        , ex.getMessage(), ex);
    }

    private void handleSuccess(Payment paymentAvro, SendResult<String, Payment> result) {
        log.info("Message sent successfully for the key : {} , and the value is {}" +
                ", partition is {}", paymentAvro.getId(), paymentAvro, result.getRecordMetadata()
                .partition());
    }
}
