package com.fab.pb.poc.dto;

import com.fab.pb.poc.domain.generated.Status;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentUpdateDTO {
    private String newStatus;
}
