package com.fab.pb.poc.service;

import com.fab.pb.poc.dto.PaymentDTO;
import com.fab.pb.poc.dto.PaymentUpdateDTO;
import com.fab.pb.poc.domain.generated.*;
import com.fab.pb.poc.producer.PaymentProducer;
import com.fab.pb.poc.producer.PaymentUpdateProducer;

import org.springframework.stereotype.Service;

import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class PaymentService {

    private PaymentProducer  paymentProducer;
    private PaymentUpdateProducer paymentUpdateProducer;

    public PaymentService(PaymentProducer paymentProducer, PaymentUpdateProducer paymentUpdateProducer) {
        this.paymentProducer = paymentProducer;
        this.paymentUpdateProducer = paymentUpdateProducer;
    }

    public PaymentDTO newPayment(PaymentDTO paymentDTO) {
        var paymentAvro = mapToPayment(paymentDTO);
        paymentDTO.setId(paymentAvro.getId().toString());
        paymentProducer.sendMessage(paymentAvro);
        return paymentDTO;
    }

    private Payment mapToPayment(PaymentDTO paymentDTO) {
        return Payment
                .newBuilder()
                .setId(UUID.randomUUID())
                .setName(paymentDTO.getName())
                .setEvent(paymentDTO.getEvent())
                .setStatus(paymentDTO.getStatus())
                .build();
    }

    public PaymentUpdateDTO updatePayment(String paymentId, PaymentUpdateDTO paymentUpdateDTO) {
        var paymentUpdateEvent = mapToPaymentUpdate(paymentId, paymentUpdateDTO);
        paymentUpdateProducer.sendMessage(paymentUpdateEvent);
        return paymentUpdateDTO;
    }

    private PaymentUpdateEvent mapToPaymentUpdate(String paymentId, PaymentUpdateDTO paymentUpdateDTO) {

        return PaymentUpdateEvent
                .newBuilder()
                .setId(UUID.fromString(paymentId))
                .setNewStatus(paymentUpdateDTO.getNewStatus())
                .build();

    }
}
