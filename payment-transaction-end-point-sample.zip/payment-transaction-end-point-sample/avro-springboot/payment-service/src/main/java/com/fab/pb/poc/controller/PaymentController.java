package com.fab.pb.poc.controller;

import com.fab.pb.poc.dto.PaymentDTO;
import com.fab.pb.poc.dto.PaymentUpdateDTO;
import com.fab.pb.poc.service.PaymentService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/payment")
@Slf4j
public class PaymentController {

    private PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PaymentDTO newOrder(@RequestBody PaymentDTO paymentDTO){
        log.info("Received the request for a payment : {}", paymentDTO);
        return paymentService.newPayment(paymentDTO);
    }

    @PutMapping("/{payment_id}")
    @ResponseStatus(HttpStatus.OK)
    public PaymentUpdateDTO updatePayment(@PathVariable("payment_id") String paymentId,
                                                  @RequestBody PaymentUpdateDTO paymentUpdateDTO){
        return paymentService.updatePayment(paymentId, paymentUpdateDTO);

    }
}
