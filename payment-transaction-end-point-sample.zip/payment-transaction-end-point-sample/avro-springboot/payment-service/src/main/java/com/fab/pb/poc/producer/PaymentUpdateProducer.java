package com.fab.pb.poc.producer;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.fab.pb.poc.domain.generated.PaymentUpdateEvent;

@Component
@Slf4j
public class PaymentUpdateProducer {

    KafkaTemplate<String, PaymentUpdateEvent> kafkaTemplate;

    public PaymentUpdateProducer(KafkaTemplate<String, PaymentUpdateEvent> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(PaymentUpdateEvent paymentAvro) {

        ProducerRecord<String, PaymentUpdateEvent> producerRecord = new ProducerRecord<String, PaymentUpdateEvent>("payment",
                paymentAvro.getId().toString(), paymentAvro);
        ListenableFuture<SendResult<String, PaymentUpdateEvent>> listenableFuture
                = kafkaTemplate.send(producerRecord);

        listenableFuture.addCallback(new ListenableFutureCallback<SendResult<String, PaymentUpdateEvent>>() {
            @Override
            public void onFailure(Throwable ex) {
                handleFailure(paymentAvro, ex);
            }

            @Override
            public void onSuccess(SendResult<String, PaymentUpdateEvent> result) {
                handleSuccess(paymentAvro, result);
            }
        });


    }

    private void handleFailure(PaymentUpdateEvent paymentAvro, Throwable ex) {
        log.error("Error Sending the message for {} and the exception is : {}", paymentAvro
        , ex.getMessage(), ex);
    }

    private void handleSuccess(PaymentUpdateEvent paymentAvro, SendResult<String, PaymentUpdateEvent> result) {
        log.info("Message sent successfully for the key : {} , and the value is {}" +
                ", partition is {}", paymentAvro.getId(), paymentAvro, result.getRecordMetadata()
                .partition());
    }
}
