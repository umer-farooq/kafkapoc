package com.fab.pb.poc.consumer;

import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.fab.pb.poc.domain.generated.Payment;
import com.fab.pb.poc.domain.generated.PaymentUpdateEvent;

@Component
@Slf4j
public class PaymentConsumer {

    @KafkaListener(topics = {"payments"},
    groupId = "${spring.kafka.consumer.group-id}" )
    public void onMessage(ConsumerRecord<String, GenericRecord> consumerRecord){
        log.info("ConsumerRecord key : {} , value {}", consumerRecord.key(), consumerRecord.value());
        var genericRecord = consumerRecord.value();

        if(genericRecord instanceof Payment){
            var payment =(Payment) genericRecord;
            log.info("payment : {}", payment);
        }else if (genericRecord instanceof PaymentUpdateEvent){
            var paymentUpdateEvent =(PaymentUpdateEvent) genericRecord;
            log.info("paymentUpdateEvent : {}", paymentUpdateEvent);
        }
    }
}
